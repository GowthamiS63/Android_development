#include <jni.h>
#include <opencv2/opencv.hpp>

using namespace cv;

extern "C"
JNIEXPORT jbyteArray JNICALL
Java_com_example_edgeviewer_MainActivity_processFrameNV21ToRGBA(JNIEnv *env, jobject thiz,
                                                                jbyteArray inputFrame, jint width, jint height) {
    jbyte *nv21 = env->GetByteArrayElements(inputFrame, NULL);
    Mat yuv(height + height/2, width, CV_8UC1, (unsigned char *)nv21);
    Mat bgr;
    cvtColor(yuv, bgr, COLOR_YUV2BGR_NV21);

    Mat gray, edges;
    cvtColor(bgr, gray, COLOR_BGR2GRAY);
    GaussianBlur(gray, gray, Size(3,3), 0);
    Canny(gray, edges, 50, 150);

    Mat rgba;
    cvtColor(edges, rgba, COLOR_GRAY2RGBA);

    if (!rgba.isContinuous()) rgba = rgba.clone();
    int outSize = rgba.total() * rgba.elemSize();
    jbyteArray outJNI = env->NewByteArray(outSize);
    env->SetByteArrayRegion(outJNI, 0, outSize, (jbyte*)rgba.data);

    env->ReleaseByteArrayElements(inputFrame, nv21, 0);
    return outJNI;
}
