# Edge Viewer - Android (OpenCV C++) + OpenGL + Web Viewer (TypeScript)

This project is prepared as a nearly-complete Android Studio project skeleton implementing:
- Camera2 capture (ImageReader YUV_420_888)
- JNI bridge to native C++ using OpenCV for edge detection
- OpenGL ES (GLSurfaceView) renderer that uploads RGBA textures
- Minimal web viewer showing a static sample frame

## Important: OpenCV binaries required
You must provide the OpenCV Android SDK or prebuilt `.so` libraries; these are NOT included here.
Two options:
1) Download OpenCV Android SDK from https://opencv.org/releases/ and copy include/ and libs into the project.
2) Add prebuilt `.so` files for each ABI into `app/src/main/jniLibs/<abi>/` and ensure headers are available.

Example: place `libopencv_java4.so` into `app/src/main/jniLibs/arm64-v8a/`

## How to open
1. Open Android Studio -> Open an existing project -> select this folder.
2. Let Android Studio download Gradle/NDK as required.
3. Configure `local.properties` with sdk.dir and ndk.dir if needed.
4. Add OpenCV files as described above.
5. Build and run on a device.

## What's included
- app/src/main/java/... MainActivity.kt (Camera2 + JNI calls)
- app/src/main/cpp/native-lib.cpp (OpenCV processing -> RGBA output)
- app/src/main/cpp/CMakeLists.txt (CMake config)
- GLTextureView.kt (GLSurfaceView renderer)
- web/ sample viewer and image
- build.gradle, settings.gradle, gradle.properties

## Limitations
- This environment cannot bundle OpenCV prebuilt binaries.
- The GLSurfaceView renderer has a minimal upload; adding a textured quad shader to sample and display the texture is recommended for production.
- You may need to adjust CMake/OpenCV paths depending on how you add OpenCV to the project.

## Next steps I can do for you (choose any):
- Add an example `local.properties` template and instructions for exact OpenCV file paths.
- Add a small shader + full textured quad drawing code in the renderer.
- Add a sample Gradle script to include an OpenCV AAR if you provide it.
- Create example commits and a ready-to-push `.git` history (I can create a simple commit log file to simulate).
